python demo/visualize_result.py --config-file ./configs/VeRi/sbs_R50-ibn.yml \
--parallel --vis-label --dataset-name 'VeRi' --output logs/mgn_duke_vis \
--opts MODEL.WEIGHTS /media/wuminghu/work/output/VeRi/fast-reid/21/veri/sbs_R50-ibn/model_final.pth