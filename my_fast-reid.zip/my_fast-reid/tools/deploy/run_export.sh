python caffe_export.py --config-file /export/home/lxy/cvpalgo-fast-reid/logs/dukemtmc/R34/config.yaml \
--name "baseline_R34" \
--output logs/caffe_R34 \
--opts MODEL.WEIGHTS /export/home/lxy/cvpalgo-fast-reid/logs/dukemtmc/R34/model_final.pth
