# encoding: utf-8
"""
@author:  Jinkai Zheng
@contact: 1315673509@qq.com
"""

import glob
import os.path as osp
import re
import os

from .bases import ImageDataset
from ..datasets import DATASET_REGISTRY


@DATASET_REGISTRY.register()
class aicity(ImageDataset):
    """aicity.

    Reference:
        Liu et al. A Deep Learning based Approach for Progressive Vehicle Re-Identification. ECCV 2016.

    URL: `<https://vehiclereid.github.io/aicity/>`_

    Dataset statistics:
        - identities: 775.
        - images: 37778 (train) + 1678 (query) + 11579 (gallery).
    """
    dataset_dir = "aicity"
    dataset_name = "aicity"

    def __init__(self, root='/media/wuminghu/work/data', **kwargs):
        self.dataset_dir = osp.join(root, self.dataset_dir)

        self.train_dir = osp.join(self.dataset_dir, 'image_train')
        self.query_dir = osp.join(self.dataset_dir, 'image_query')
        self.gallery_dir = osp.join(self.dataset_dir, 'image_test')

        required_files = [
            self.dataset_dir,
            self.train_dir,
            self.query_dir,
            self.gallery_dir,
        ]
        self.check_before_run(required_files)

        train = self.process_dir(self.train_dir)
        query = self.process_dir(self.query_dir, is_train=False)
        gallery = self.process_dir(self.gallery_dir, is_train=False)

        super(aicity, self).__init__(train, query, gallery, **kwargs)

    def process_dir(self, dir_path, is_train=True):
        # img_paths = glob.glob(osp.join(dir_path, '*.jpg'))
        pattern = re.compile(r'([\d]+)_c(\d\d\d)')

        data = []
        for img_dir in os.listdir(dir_path):
            img_paths = glob.glob(osp.join(os.path.join(dir_path,img_dir) , '*.jpg'))
            # print(img_dir)
            for img_path in img_paths:
                pid, camid = map(int, pattern.search(img_path).groups())
                # print(pid,camid)
                if pid == -1: continue  # junk images are just ignored
                # assert 1 <= pid <= 776
                # assert 1 <= camid <= 20
                camid -= 1  # index starts from 0
                if is_train:
                    pid = self.dataset_name + "_" + str(pid)
                data.append((img_path, pid, camid))

        return data
