from .market1501 import Market1501
from .dukemtmcreid import DukeMTMCreID
from .msmt17 import MSMT17
from .veri import VeRi
from .build_datasets import build_train_dataset, build_test_dataset
