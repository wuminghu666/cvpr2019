import argparse, ast
import sys
sys.path.append('/home/wuminghu/re-id/light-reid')
import logging
import os
import torch
import torch.nn as nn
import lightreid


# Settings
parser = argparse.ArgumentParser()
parser.add_argument('--results_dir', type=str, default='./results/', help='path to save outputs')
parser.add_argument('--dataset', type=str, default='dukemtmcreid', help='')
parser.add_argument('--lightmodel', type=ast.literal_eval, default=False, help='train a small model with model distillation')
parser.add_argument('--lightfeat', type=ast.literal_eval, default=False, help='learn binary codes NOT real-value code')
parser.add_argument('--lightsearch', type=ast.literal_eval, default=False, help='lightfeat should be True if lightsearch is True')

#######################################################################check
"""
Create a parser with some common arguments used by fastreid users.
Returns:
    argparse.ArgumentParser:
"""
parser.add_argument("--config-file", default="", metavar="FILE", help="path to config file")
parser.add_argument(
    "--resume",
    action="store_true",
    help="whether to attempt to resume from the checkpoint directory",
)
parser.add_argument("--eval-only", action="store_true", help="perform evaluation only")
parser.add_argument("--num-gpus", type=int, default=1, help="number of gpus *per machine*")
parser.add_argument("--num-machines", type=int, default=1, help="total number of machines")
parser.add_argument(
    "--machine-rank", type=int, default=0, help="the rank of this machine (unique per machine)"
)

# PyTorch still may leave orphan processes in multi-gpu training.
# Therefore we use a deterministic way to obtain port,
# so that users are aware of orphan processes by seeing the port occupied.
port = 2 ** 15 + 2 ** 14 + hash(os.getuid() if sys.platform != "win32" else 1) % 2 ** 14
parser.add_argument("--dist-url", default="tcp://127.0.0.1:{}".format(port))
parser.add_argument(
    "opts",
    help="Modify config options using the command-line",
    default=None,
    nargs=argparse.REMAINDER,
)
#######################################################################check
args = parser.parse_args()




# build dataset
# DUKE_PATH = '/home/Monday/datasets/DukeMTMC-reID'
datamanager = lightreid.data.DataManager(
    sources=lightreid.data.build_train_dataset([args.dataset]),
    target=lightreid.data.build_test_dataset(args.dataset),
    transforms_train=lightreid.data.build_transforms(img_size=[384, 128], transforms_list=['randomflip', 'padcrop', 'rea']),
    transforms_test=lightreid.data.build_transforms(img_size=[384, 128], transforms_list=[]),
    sampler='pk', p=11, k=6)

#######################################################################check_build model
sys.path.append('/home/wuminghu/re-id/light-reid/fast-reid')
from fastreid.config import get_cfg
from fastreid.engine import DefaultTrainer, default_argument_parser, default_setup, launch
from fastreid.utils.checkpoint import Checkpointer
from fastreid.evaluation import ReidEvaluator
##import model
from fastreid.layers import *
from fastreid.modeling.meta_arch.baseline import Baseline
from fastreid.modeling.backbones import build_backbone
from fastreid.modeling.heads import build_reid_heads
from fastreid.layers import GeneralizedMeanPoolingP, AdaptiveAvgMaxPool2d, FastGlobalAvgPool2d
from fastreid.solver.build import build_lr_scheduler, build_optimizer
##import model
def setup(args):
    """
    Create configs and perform basic setups.
    """
    cfg = get_cfg()
    cfg.merge_from_file(args.config_file)
    cfg.merge_from_list(args.opts)
    cfg.freeze()
    default_setup(cfg, args)
    return cfg
cfg = setup(args)
# trainer = DefaultTrainer(cfg)
# the_baseline=Baseline(cfg)
the_backbone=build_backbone(cfg)
the_pooling=pool_layer = GeneralizedMeanPoolingP()
head_classifier=CircleSoftmax(cfg, cfg.MODEL.HEADS.IN_FEAT, datamanager.class_num)
# the_head=build_reid_heads(cfg, cfg.MODEL.HEADS.IN_FEAT, datamanager.class_num, the_pooling)
# the_head=lightreid.models.BNHead(in_dim=cfg.MODEL.HEADS.IN_FEAT, class_num=datamanager.class_num)
the_head=lightreid.models.BNHead(in_dim=cfg.MODEL.HEADS.IN_FEAT, class_num=datamanager.class_num,classifier=head_classifier)
model = lightreid.models.BaseReIDModel(backbone=the_backbone, pooling=the_pooling, head=the_head)
# build optimizer
the_optimizer = build_optimizer(cfg, model)
the_scheduler = build_lr_scheduler(cfg, the_optimizer)
the_optimizer = lightreid.optim.Optimizer(optimizer=the_optimizer, lr_scheduler=the_scheduler, max_epochs=200)
# build loss
criterion = lightreid.losses.Criterion([
    {'criterion': lightreid.losses.CrossEntropyLabelSmooth(num_classes=datamanager.class_num), 'weight': 1.0},
    {'criterion': lightreid.losses.TripletLoss(margin='soft', metric='euclidean'), 'weight': 1.0},
])
# run
solver = lightreid.engine.Engine(cfg,
    results_dir=args.results_dir, datamanager=datamanager, model=model, criterion=criterion, optimizer=the_optimizer, use_gpu=True,
    light_model=args.lightmodel, light_feat=args.lightfeat, light_search=args.lightsearch)
# import pdb; pdb.set_trace()
#######################################################################check_build model

# # # build model
# backbone = lightreid.models.backbones.resnet50(pretrained=True, last_stride_one=True)
# pooling = nn.AdaptiveAvgPool2d(1)
# head = lightreid.models.BNHead(in_dim=backbone.dim, class_num=datamanager.class_num)
# model = lightreid.models.BaseReIDModel(backbone=backbone, pooling=pooling, head=head)
#######################################################################check

# # build loss
# criterion = lightreid.losses.Criterion([
#     {'criterion': lightreid.losses.CrossEntropyLabelSmooth(num_classes=datamanager.class_num), 'weight': 1.0},
#     {'criterion': lightreid.losses.TripletLoss(margin='soft', metric='euclidean'), 'weight': 1.0},
# ])

# # build optimizer
# optimizer = torch.optim.Adam(model.parameters(), lr=0.00035, weight_decay=5e-4)
# lr_scheduler = lightreid.optim.WarmupMultiStepLR(optimizer, milestones=[40, 70], gamma=0.1, warmup_factor=0.01, warmup_epochs=10)
# optimizer = lightreid.optim.Optimizer(optimizer=optimizer, lr_scheduler=lr_scheduler, max_epochs=120)

# # run
# solver = lightreid.engine.Engine(cfg,
#     results_dir=args.results_dir, datamanager=datamanager, model=model, criterion=criterion, optimizer=optimizer, use_gpu=True,
#     light_model=args.lightmodel, light_feat=args.lightfeat, light_search=args.lightsearch)
#################################################################################################check
# train
solver.train(eval_freq=10)
# # test
# solver.resume_latest_model()
# # solver.smart_eval(onebyone=True, mode='normal')
# solver.eval()
# # visualize
# solver.visualize()

