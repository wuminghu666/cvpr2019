# StrongerBaseline(SBS)

implement and speedup StrongerBaseline(SBS) with light-reid

## Experimental Results and Trained Models

comming soon